package br.com.api.sgct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgctApplicationTests {

	@Test
	void contextLoads() {
	}

}
