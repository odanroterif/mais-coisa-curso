package br.com.api.sgct.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.sgct.modelo.Chamado;
import br.com.api.sgct.repositorio.ChamadoRepositorio;

@Service
public class ChamadoServico {
    
    @Autowired
    private ChamadoRepositorio cr;

    public List<Chamado> listartodos(){
        return cr.findAll();
    }

    public Optional<Chamado> buscarPorId(Long id){
        return cr.findById(id);
    }

    public Chamado salvar(Chamado chamado){
        return cr.save(chamado);
    }

    public void deletar(Long id){
        cr.deleteById(id);
    }
}
