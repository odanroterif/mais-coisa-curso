const forM = document.querySelector('.form-chamado');
const description = document.querySelector('#descricao');
const mail = document.querySelector('#email');
const urgency = document.querySelector('#urgencia');
const button = document.querySelector('.btn-submit');


button.addEventListener('click', sign_CALL);

function sign_CALL() {

    forM.append('descricao',description);
    forM.append('prioridade',urgency);

    try 
    {
        fetch("http://localhost:8080/chamados", {
            method: "post",
            body: forM,
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json"
            }
        })
            .then(response => response.json())
            .then(response_convert => {
                if (response_convert.message !== undefined) {
                    
                }
                else {                
                    alert("CHAMADO ENVIADO.")
                }
            });        
    } catch (error) 
    {
        alert(error.message)
    }
};